import java.util.*;
import java.io.*;

public class Manager {
	private ArrayList<Product> media = new ArrayList<>();
	
	public void loadData(String fileName) {
		try(BufferedReader br = new BufferedReader(new FileReader (fileName))){;
		String line;
		
		while((line = br.readLine()) != null) {
			String[] data = line.split(",");
			String id = data[0];
			String type = data[1];
			String title = data[2];
			int release = Integer.parseInt(data[4]);
			
			//Divide all data into there own sepreate parts with if statements
			if() {
				
			}
			else if() {
				
			}
			else if() {
				
			}
			else if() {
				
			}
		}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
	//Create different functions for the call in the Driver
	public int countProduct() {
		return 0; //temp values
	}
	public int countMovies() {
		return 0;  //temp values
	}
	public int countGames() {
		return 0;	//temp values
	}
	public int countShows() {
		return 0;	//temp values
	}
	public int countMusic() {
		return 0;	//temp values
	}
}

