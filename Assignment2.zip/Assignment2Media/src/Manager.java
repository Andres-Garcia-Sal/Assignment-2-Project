import java.util.*;
import java.io.*;

public class Manager {
	private ArrayList<Product> media = new ArrayList<>();
	
	public void loadData(String fileName) {
		   File file = new File(fileName);
		    try{
		      Scanner scnr = new Scanner(file);
		      while(scnr.hasNextLine()){
		    	  String name = scnr.next();
		    	  String[] data = name.split(","); 
		    	  
		          int id = Integer.parseInt(data[0]); 
		          String type = data[1]; 
		          String title = data[2]; 
		          int release = Integer.parseInt(data[4]); 
		          
		      if(type.equalsIgnoreCase("Movie")) { 
		              String director = data[5]; 
		              String country = data[6]; 
		              String rating = data[7]; 
		              int duration = Integer.parseInt(data[8]); 
		              String description = data[9]; 

		              Movie movie = new Movie(id, type, title, release, director, country, rating, duration, description); 
		              media.add(movie); 
		            }
		      else if(type.equalsIgnoreCase("TV Show")) { 
		              String director = data[5]; 
		              String country = data[6]; 
		              String rating = data[7]; 
		              String seasonNum = data[10]; 
		              String description = data[9]; 

		              TvShow show = new TvShow(id, type, title, release, director, country, rating, seasonNum, description); 
		              media.add(show); 
		            } 
		      else if(type.equalsIgnoreCase("Video Game")) { 
		              String platform = data[11]; 
		              String genre = data[12]; 
		              String publisher = data[13]; 
		              double copySold = Double.parseDouble(data[14]); 

		              VideoGames game = new VideoGames(id, type, title, release, platform, genre, publisher, copySold); 
		              media.add(game); 
		            } 
		       else if(type.equalsIgnoreCase("Music Album")) { 
		              String artist = data[15]; 
		              int globalSales = Integer.parseInt(data[16]); 
		              int trackNum = Integer.parseInt(data[17]); 
		              double duration = Double.parseDouble(data[18]); 
		              String genre = data[19]; 

		              Music album = new Music(id, type, title, release, artist, globalSales, trackNum, duration, genre); 
		              media.add(album); 
		            } 
		    }
		      scnr.close();
		    }
		    catch(FileNotFoundException e){
		      e.printStackTrace();
		      System.out.println("File not found");
		    }
	}
	
	//Create different functions for the call in the Driver
	public int countProduct() {
		return media.size(); //temp values
	}
	public int countMovies() {
		return 0;  //temp values
	}
	public int countGames() {
		return 0;	//temp values
	}
	public int countShows() {
		return 0;	//temp values
	}
	public int countMusic() {
		return 0;	//temp values
	}
	
}

