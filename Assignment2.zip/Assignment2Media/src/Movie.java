
public class Movie extends Product {
	private String Director;
	private String Country;
	private String rating;
	private int minDuration;
	private String description;
	
	public Movie(int ID, String type, String title, int releaseYear, String Director, String Country, String rating, int minDuration, String description) {
		super(ID,type,title,releaseYear);
		this.Director = Director;
		this.Country = Country;
		this.rating = rating;
		this.minDuration = minDuration;
		this.description = description;
	}
	
	public String getDirector() {
		return Director;
	}
	public void setDirector(String Director) {
		this.Director = Director;
	}
	
	public String getCountry() {
		return Country;
	}
	public void setCountry(String Country) {
		this.Country = Country;
	}
	
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	
	public int getDuration() {
		return minDuration;
	}
	public void setDuration(int minDuration) {
		this.minDuration = minDuration;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
